<?php
$db = [
    array(
        "id" => "1",
        "nombre" => "Green Dress with details",
        "precio" => "22.90",
        "imagen" => "img/products/img-1.jpg",
        "status" => "new",
        "categoria" => array("dresses", "bags"),
    ),array(
        "id" => "2",
        "nombre" => "Yellow Maxi Dress",
        "precio" => "25.90",
        "imagen" => "img/products/img-2.jpg",
        "status" => "sale",
        "categoria" => array("dresses", "bags"),
    ),array(
        "id" => "3",
        "nombre" => "One piece bodysuit",
        "precio" => "19.90",
        "imagen" => "img/products/img-3.jpg",
        "status" => "new",
        "categoria" => array("shoes", "accesories"),
    ),array(
        "id" => "4",
        "nombre" => "Blue Dress with details",
        "precio" => "35.50",
        "imagen" => "img/products/img-4.jpg",
        "status" => "popular",
        "categoria" => array("shoes", "accesories"),
    ),array(
        "id" => "5",
        "nombre" => "Green Dress with details",
        "precio" => "22.90",
        "imagen" => "img/products/img-5.jpg",
        "status" => "new",
        "categoria" => array("dresses", "shoes"),
    ),array(
        "id" => "6",
        "nombre" => "Yellow Maxi Dress",
        "precio" => "25.90",
        "imagen" => "img/products/img-6.jpg",
        "status" => "sale",
        "categoria" => array("accesories", "bags"),
    ),array(
        "id" => "7",
        "nombre" => "One piece bodysuit",
        "precio" => "19.90",
        "imagen" => "img/products/img-7.jpg",
        "status" => "none",
        "categoria" => array("dresses", "bags"),
    ),array(
        "id" => "8",
        "nombre" => "Blue Dress with details",
        "precio" => "35.50",
        "imagen" => "img/products/img-8.jpg",
        "status" => "popular",
        "categoria" => array("accesories", "bags"),
    ),
];


/* foreach($db as $xddd) {
    echo $xddd["nombre"] . " - " . $xddd["precio"] . "<br>";
    echo "<img src=' " . $xddd["imagen"] . " '> " . "<br>";
}; */
?>
